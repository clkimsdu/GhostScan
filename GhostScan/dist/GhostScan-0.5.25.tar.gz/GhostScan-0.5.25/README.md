#GhostScan
Package used to analyze images from a wide range of cameras

